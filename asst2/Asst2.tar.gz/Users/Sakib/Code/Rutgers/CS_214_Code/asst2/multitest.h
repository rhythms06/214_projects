#ifndef _MULTITEST_H
#define _MULTITEST_H

#define NOT_FOUND 255

#define search dummy_search
void dummy_search(int, int*, int, int, int*);

#endif
